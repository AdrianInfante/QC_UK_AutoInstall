﻿# Check if the current script is running with administrative privileges

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # Relaunch the script with elevated privileges
    $scriptPath = $MyInvocation.MyCommand.Path
    Start-Process -FilePath "powershell" -ArgumentList "-File `"$scriptPath`"" -Verb runAs
    exit
}




#Enable powershell scripting

$desiredPolicy = "RemoteSigned"

try {
    $currentPolicy = Get-ExecutionPolicy -Scope MachinePolicy -ErrorAction Stop

    if ($currentPolicy -ne $desiredPolicy) {
        Set-ExecutionPolicy -ExecutionPolicy $desiredPolicy -Scope MachinePolicy -Force
    }
}

catch {

    #Write-Host "An error occurred while setting the execution policy: $($_.Exception.Message)"
}





# Check if MegaRAID Storage Manager installation folder exists
if (Test-Path "C:\Program Files (x86)\MegaRAID Storage Manager") {
   # Change directory to MegaRAID Storage Manager installation folder
cd "C:\Program Files (x86)\MegaRAID Storage Manager"

# Execute storcli64.exe command
$result = .\storcli64.exe /c0 /eall /sall show | Select-Object -Skip 3 | ForEach-Object { ($_ -split '\s+')[2,4,5,6,10,11] -join "`t" }

.\storcli64.exe /c0 /eall /sall show | Select-Object -Skip 3 | Where-Object { $_ -notmatch 'Slt-Slot|DG-DriveGroup|Spare|UGood-Unconfigured|Encryptive|Info|shielded|Shielded' } | ForEach-Object { ($_ -split '\s+')[2,4,5,6,10,11] -join "`t" }


# Count the number of HDDs
$count = ($result | Select-String -Pattern "Onln" | Measure-Object).Count

#Write-Host $result

# Display the count
Write-Host "Number HDD online: "$count

# Initialize a counter variable
$count2 = 0

# Iterate through each line of the output and count HDD entries
foreach ($line in $result) {
    # Check if the line contains any size information
    if ($line -match "\d+(\.\d+)?\sTB") {
        $count2++
    }
}

    # Display the count
    Write-Host "Number HDD total: "$count2

 # Prompt the user to press a key before exiting
    Write-Host " "
    Write-Host "Press Enter to exit..."
    $null = Read-Host

} else {
    # Display message if MegaRAID Storage Manager installation folder is not found
    Write-Host "MegaRAID Storage Manager is not installed on this system."
    Write-Host " "
    Write-Host "Press Enter to exit..."
    $null = Read-Host
}
