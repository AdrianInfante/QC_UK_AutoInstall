﻿#*****************************************************GLOBAL VARIABLES*****************************************************

#*************************FTP
$driveLetter = "Z"
$networkPath = "\\10.253.0.3\ftp$"
$username = "SERVER\User"
$password = "Password" | ConvertTo-SecureString -AsPlainText -Force

$desiredPolicy = "RemoteSigned"

try {
    $currentPolicy = Get-ExecutionPolicy -Scope MachinePolicy -ErrorAction Stop

    if ($currentPolicy -ne $desiredPolicy) {
        Set-ExecutionPolicy -ExecutionPolicy $desiredPolicy -Scope MachinePolicy -Force
    }
}

catch {

    #Write-Host "An error occurred while setting the execution policy: $($_.Exception.Message)"
}

#Enable powershell scripting*****************************************************

# Check if the current script is running with administrative privileges

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # Relaunch the script with elevated privileges
    $scriptPath = $MyInvocation.MyCommand.Path
    Start-Process -FilePath "powershell" -ArgumentList "-File `"$scriptPath`"" -Verb runAs
    exit
}





#*****************************************************ART*****************************************************

$asciiArt = @"
 
                                     .-.            
                                    |_:_|               
                                   /(_Y_)\         
              ,                   ( \/M\/ )             
               *,               _.'-/'-'\-'._       
                 *,           _/.--'[[[[]'--.\_
                   *,        /_'  : |::"| :  '.\
                     *,     //   ./ |oUU| \.'  :\
                       *,  _:'..' \_|___|_/ :   :|
                         *,.  .'  |_[___]_|  :.':\
                          [::\ |  :  | |  :   ; : \
                           '-'   \/'.| |.' \  .;.' |
                           |\_    \  '-'   :       |
                           |  \    \ .:    :   |   |
                           |   \    | '.   :    \  |
                           /       \   :. .;       |
                          /     |   |  :__/     :  \\
                          |  |   |    \:   | \   |   ||
                         /    \  : :  |:   /  |__|   /|
                         |     : : :_/_|  /'._\  '--|_\
                         /___.-/_|-'   \  \
                                        '-'
Status | Taks
_______|___________________________________________________________________________________                                                                                      
"@ 






#TERMINAL UI SETTINGS*****************************************************

#Open Powershell terminal in the center of the screen
Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;

    public class Window
    {
        [DllImport("user32.dll")]
        public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, uint uFlags);

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        public static extern IntPtr GetDesktopWindow();

        public const uint SWP_SHOWWINDOW = 0x0040;
        public const int SWP_NOSIZE = 0x0001;
        public const int SWP_NOMOVE = 0x0002;

        public static void CenterWindow()
        {
            IntPtr hWndConsole = GetConsoleWindow();
            IntPtr hWndDesktop = GetDesktopWindow();

            RECT consoleRect;
            GetWindowRect(hWndConsole, out consoleRect);

            RECT desktopRect;
            GetWindowRect(hWndDesktop, out desktopRect);

            int width = consoleRect.right - consoleRect.left;
            int height = consoleRect.bottom - consoleRect.top;

            int x = (desktopRect.right - desktopRect.left - width) / 2;
            int y = (desktopRect.bottom - desktopRect.top - height) / 2;

            SetWindowPos(hWndConsole, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    }
"@

[Window]::CenterWindow()



# Function to update and display the window size

function Update-WindowSize {
    $windowWidth = [System.Console]::WindowWidth
    $windowHeight = [System.Console]::WindowHeight

    #Write-Host "Window Width: $windowWidth"
    #Write-Host "Window Height: $windowHeight"
}

# Get the available screen buffer size
$screenBufferWidth = [System.Console]::BufferWidth
$screenBufferHeight = [System.Console]::BufferHeight

# Calculate the desired window size
$desiredWidth = 97
$desiredHeight = 43

# Adjust the window size if it exceeds the screen buffer
if ($desiredWidth -gt $screenBufferWidth) {
    $desiredWidth = $screenBufferWidth
}

if ($desiredHeight -gt $screenBufferHeight) {
    $desiredHeight = $screenBufferHeight
}

# Limit the desired height to a maximum of 63
if ($desiredHeight -gt 43) {
    $desiredHeight = 43
}

# Set the terminal size
[System.Console]::SetWindowSize($desiredWidth, $desiredHeight)
[System.Console]::SetBufferSize($desiredWidth, $desiredHeight)

# Update and display the window size
Update-WindowSize

#MAIN WINDOW SELECTION*****************************************************

Write-Host @"

           



                                                                                                                     



                        ooooooooooooooooooooooooooooooooooooo
                        8                                .d88
                        8  oooooooooooooooooooooooooooood8888
                        8  8888888888888888888888888P"   8888    oooooooooooooooo
                        8  8888888888888888888888P"      8888    8              8
                        8  8888888888888888888P"         8888    8             d8
                        8  8888888888888888P"            8888    8            d88
                        8  8888888888888P"               8888    8           d888
                        8  8888888888P"                  8888    8          d8888
                        8  8888888P"                     8888    8         d88888
                        8  8888P"                        8888    8        d888888
                        8  8888oooooooooooooooooooooocgmm8888    8       d8888888
                        8 .od88888888888888888888888888888888    8      d88888888
                        8888888888888888888888888888888888888    8     d888888888
                                                                 8    d8888888888
                            ooooooooooooooooooooooooooooooo      8   d88888888888
                           d                       ...oood8b     8  d888888888888
                          d              ...oood888888888888b    8 d8888888888888
                         d     ...oood88888888888888888888888b   8d88888888888888
                        dood8888888888888888888888888888888888b
                                      




                          PLEASE, SELECT ANY OPTION TO START:
                          ____________________________________

                                [1] VLR
                                [2] CLIENT ON BOARD GPU
                                [3] CLIENT EXTERNAL GPU




                              

"@

#SELECTION MENU*****************************************************
    
# Process the user's choice using a switch statement
$choiceM = [Console]::ReadKey().KeyChar.ToString()

# Process the user's choice using a switch statement
switch ($choiceM)
{
'1' {
        $electionV = 'VLR'
        
        
# Prompt the user for input
Write-Host @"

           








                                 _    ____    ____        ____  ______
                                | |  / / /   / __ \      / __ \/ ____/
                                | | / / /   / /_/ /_____/ / / / /     
                                | |/ / /___/ _, _/_____/ /_/ / /___   
                                |___/_____/_/ |_|      \___\_\____/   
                                      

                                PLEASE, SELECT THE COUNTRY TO START:
                                ____________________________________

                                [1] UK
                                [2] GERMANY
                                [3] KUWAIT
                                [4] EGYPT
                                [5] FRANCE
                                [6] ITALY
                                [7] ABUDHABI
                                [8] BACK TO MENU














"@

# Process the user's choice using a switch statement
$choice = [Console]::ReadKey().KeyChar.ToString()

# Process the user's choice using a switch statement
switch ($choice)
{
    '1' {
        $election = 'UK'
        
    }
    '2' {
        $election = 'GERMANY'
        
    }
    '3' {
        $election = 'KUWAIT'
        
    }
    '4' {
        $election = 'EGYPT'
        
    }
    '5' {
        $election = 'FRANCE'
        
    }
    '6' {
        $election = 'ITALY'
        
    }
    '7' {
        $election = 'ABUDHABI'
        
    }
    '8' {
        # Restart the script by calling it again
        $scriptPath = $MyInvocation.MyCommand.Path
        Clear-Host
        & $scriptPath
        return
        
        
    }

    Default {
     $scriptPath = $MyInvocation.MyCommand.Path

    while ($true) {
        Write-Host "                               Select a number and try again..."
    
        # Optional: Add a delay if desired
        Start-Sleep -Seconds 3
    
        # Call the script again
        Clear-Host
        & $scriptPath
        }
    }
}

        
    }
    '2' {
        $electionV = 'CLIENT'
        # Prompt the user for input
Write-Host @"

           




 
                                    
        



                                

                        ______     __         __     ______     __   __     ______  
                       /\  ___\   /\ \       /\ \   /\  ___\   /\ "-.\ \   /\__  _\ 
                       \ \ \____  \ \ \____  \ \ \  \ \  __\   \ \ \-.  \  \/_/\ \/ 
                        \ \_____\  \ \_____\  \ \_\  \ \_____\  \ \_\\"\_\    \ \_\ 
                         \/_____/   \/_____/   \/_/   \/_____/   \/_/ \/_/     \/_/ 
                                                                                                                                                                                  
                                                                             NO GPU 

                                   

                                PLEASE, SELECT THE COUNTRY TO START:
                                ____________________________________

                                [1] UK
                                [2] GERMANY
                                [3] KUWAIT
                                [4] EGYPT
                                [5] FRANCE
                                [6] ITALY
                                [7] ABUDHABI
                                [8] BACK TO MENU













"@

# Process the user's choice using a switch statement
$choice = [Console]::ReadKey().KeyChar.ToString()

# Process the user's choice using a switch statement
switch ($choice)
{
    '1' {
        $election = 'UK'
        
    }
    '2' {
        $election = 'GERMANY'
        
    }
    '3' {
        $election = 'KUWAIT'
        
    }
    '4' {
        $election = 'EGYPT'
        
    }
    '5' {
        $election = 'FRANCE'
        
    }
    '6' {
        $election = 'ITALY'
        
    }
    '7' {
        $election = 'ABUDHABI'
        
    }
    '8' {
        # Restart the script by calling it again
        $scriptPath = $MyInvocation.MyCommand.Path
        Clear-Host
        & $scriptPath
        return
        
        
    }
    Default {
    
    $scriptPath = $MyInvocation.MyCommand.Path

    while ($true) {
        Write-Host "                               Select a number and try again..."
    
        # Optional: Add a delay if desired
        Start-Sleep -Seconds 3
    
        # Call the script again
        Clear-Host
        & $scriptPath
        }
    }
}
    }
    '3' {
        $electionV = 'CLIENT'

        # Prompt the user for input
Write-Host @"

           






        



                                

                        ______     __         __     ______     __   __     ______  
                       /\  ___\   /\ \       /\ \   /\  ___\   /\ "-.\ \   /\__  _\ 
                       \ \ \____  \ \ \____  \ \ \  \ \  __\   \ \ \-.  \  \/_/\ \/ 
                        \ \_____\  \ \_____\  \ \_\  \ \_____\  \ \_\\"\_\    \ \_\ 
                         \/_____/   \/_____/   \/_/   \/_____/   \/_/ \/_/     \/_/ 
                                                                                                                                                                                  
                                                                             WITH GPU 

                                   

                                PLEASE, SELECT THE COUNTRY TO START:
                                ____________________________________

                                [1] UK
                                [2] GERMANY
                                [3] KUWAIT
                                [4] EGYPT
                                [5] FRANCE
                                [6] ITALY
                                [7] ABUDHABI
                                [8] BACK TO MENU













"@



# Process the user's choice using a switch statement
$choice = [Console]::ReadKey().KeyChar.ToString()



# Process the user's choice using a switch statement
switch ($choice)
{
    '1' {
        $election = 'UK'

    }

    '2' {
        $election = 'GERMANY'
        
    }
    '3' {
        $election = 'KUWAIT'
        
    }
    '4' {
        $election = 'EGYPT'
        
    }
    '5' {
        $election = 'FRANCE'
        
    }
    '6' {
        $election = 'ITALY'
        
    }
    '7' {
        $election = 'ABUDHABI'
        
    }
    '8' {
        # Restart the script by calling it again
        $scriptPath = $MyInvocation.MyCommand.Path
        Clear-Host
        & $scriptPath
        return
        
        
    }
    Default {
    
    $scriptPath = $MyInvocation.MyCommand.Path

    while ($true) {
        Write-Host "                               Select a number and try again..."
    
        # Optional: Add a delay if desired
        Start-Sleep -Seconds 3
    
        # Call the script again
        Clear-Host
        & $scriptPath
        }
    }
}
 
    }
    Default {
     $scriptPath = $MyInvocation.MyCommand.Path

    while ($true) {
        Write-Host "                               Select a number and try again..."
    
        # Optional: Add a delay if desired
        Start-Sleep -Seconds 3
    
        # Call the script again
        Clear-Host
        & $scriptPath
        }
    }
}

#DELAY*****************************************************

# Add a delay of 5 seconds for the user to cancel
$Countdown = 5
$cancelKeyPressed = $false
$endTime = (Get-Date).AddSeconds(5)

while ((Get-Date) -lt $endTime -and $Countdown -ge 0 ) {
 Clear-Host

switch ($Countdown) {
        5 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
        }
        4 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
        }
        3 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
        }
        2 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
        }
        1 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
        }
        0 {
        Write-Host " "
Write-Host " YOU HAVE $Countdown SECONDS TO PRESS THE ESC KEY TO CANCEL *** $election *** OPTION... " -ForegroundColor Green
Clear-Host
        }
        default {
            # Code to execute if the countdown is not any of the specified numbers
            Write-Host "Countdown is not within the expected range"
        }
    }

    Start-Sleep -Seconds 1
    $Countdown--


    if ([Console]::KeyAvailable) {
        $key = [Console]::ReadKey($true)

        if ($key.Key -eq "Escape") {
            $cancelKeyPressed = $true
             $scriptPath = $MyInvocation.MyCommand.Path
            while ($true) {
            Write-Host "Restarting script..."
    
            # Optional: Add a delay if desired
            Start-Sleep -Seconds 3
    
            # Call the script again
            Clear-Host
            & $scriptPath
            
    }
        }
    }

   
}



Clear-Host




 # Go back to the select menu if the script is canceled
    if ($cancelKeyPressed) {
     # Clear the screen
        Clear-Host
        & $MyInvocation.MyCommand.Path
    }

foreach ($line in $asciiArt -split "`n")
{
    foreach ($char in $line.ToCharArray())
    {
        switch ($char)
        {
            ',' {Write-Host -ForegroundColor Red $char -NoNewline}
            '*' {Write-Host -ForegroundColor Red $char -NoNewline}
            'o' {Write-Host -ForegroundColor Red $char -NoNewline}
            '1' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '2' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '3' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '4' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '5' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '6' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            '7' {Write-Host -ForegroundColor Yellow $char -NoNewline}
            Default {Write-Host $char -NoNewline}
        }
    }
    Write-Host ""
}

foreach ($line in $Warning -split "`n")
{
    foreach ($char in $line.ToCharArray())
    {
        switch ($char)
        {
            '#' {Write-Host -ForegroundColor Cyan $char -NoNewline}
            ':' {Write-Host -ForegroundColor Cyan $char -NoNewline}
            '.' {Write-Host -ForegroundColor White $char -NoNewline}
            Default {Write-Host $char -NoNewline}
        }
    }
    Write-Host ""
}

#REMOVE EXISTING FTP DRIVE*****************************************************

# Remove the existing drive with the same name if it exists
if (Get-PSDrive -Name $driveLetter -ErrorAction SilentlyContinue) {
    Remove-PSDrive -Name $driveLetter -ErrorAction SilentlyContinue
}

#*ENABLE PS SCRIPTING*****************************************************??????

$desiredPolicy = "RemoteSigned"

try {
    $currentPolicy = Get-ExecutionPolicy -Scope MachinePolicy -ErrorAction Stop

    if ($currentPolicy -ne $desiredPolicy) {
        Set-ExecutionPolicy -ExecutionPolicy $desiredPolicy -Scope MachinePolicy -Force
    }
}

catch {

    #Write-Host "An error occurred while setting the execution policy: $($_.Exception.Message)"
}



#Write-Host " "
Write-Host "[✔ ] ~ Powershell scripting enabled" -ForegroundColor Green
Start-Sleep -Seconds 2

#-CHANGE PC NAME------------------------------------------------------------------

try
{
     # Find the computer name
    $computerName = $env:COMPUTERNAME
    $date = Get-Date -Format "ddMyyHHmm"   
    $datePerformed = Get-Date -Format "ddMMyyyy"
    $computerNamePrefix = $computerName -split "-$electionV" | Select-Object -First 1
    $newName = "$electionV-" + ($date -replace "[^A-Za-z0-9-]","")  # Ensure only valid characters

    # Attempt to rename the computer
    Rename-Computer -NewName $newName -Force

    # If renaming was successful
    $result = "The computer has been renamed to: $newName"
}
catch [System.Management.Automation.RuntimeException]
{
    Write-Host "$_.Exception.Message"
    #Write-Host "[❌] ~ The new PC name :" + $newName + "Exceed the max 15 characters allowed. No action taken" -ForegroundColor Red 
    #$result ="`n[X] ~ The new PC name :" + $newName + "Exceed the max 15 characters allowed. No action taken"
}

#CHANGE POWER PLAN---------------------------------------------------------------------

# Set the display to never turn off
powercfg -change -monitor-timeout-ac 0
Write-Host "[✔ ] ~ Display turn off set to Never" -ForegroundColor Green
Start-Sleep -Seconds 2

# Prevent the computer from going to sleep
powercfg -change -standby-timeout-ac 0
powercfg -change -hibernate-timeout-ac 0
Write-Host "[✔ ] ~ Prevent the computer from going to sleep set to Never" -ForegroundColor Green
Start-Sleep -Seconds 2

#CHANGE TIME ZONE------------------------------------------------------------------

switch ($choice) {
    "1" {
        
       # Set the time zone to London
        Set-TimeZone -Id "GMT Standard Time" 
        Write-Host "[✔ ] ~ Time zone set to London" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "2" {
        Set-TimeZone -Id "W. Europe Standard Time"
        Write-Host "[✔] ~ Time zone set to GMT+1" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "3" {
        Set-TimeZone -Id "Arabian Standard Time"
        Write-Host "[✔] ~ Time zone set to GMT+3" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "4" {
        Set-TimeZone -Id "Egypt Standard Time"
        Write-Host "[✔] ~ Time zone set to Cairo GMT+2" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "5" {
        Set-TimeZone -Id "W. Europe Standard Time"
        Write-Host "[✔] ~ Time zone set to GMT+1" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "6" {
        Set-TimeZone -Id "W. Europe Standard Time"
        Write-Host "[✔] ~ Time zone set to GMT+1" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "7" {
        Set-TimeZone -Id "Arabian Standard Time"
        Write-Host "[✔] ~ Time zone set to GMT+4" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }

    Default {
        Write-Host "Invalid choice. Please enter a valid option (1, for UK )."
    }
}


#CHANGE REGION------------------------------------------------------------------

switch ($choice) {
    "1" {
        
       # Set the region to United Kingdom
        Set-WinSystemLocale -SystemLocale en-GB 
        Set-WinUserLanguageList -LanguageList en-GB -Force
        Set-Culture -CultureInfo "en-GB" 
        $country = (Get-Culture).Name

        # Check if $country is equal to "en-GB" and set to "UK" if true
        if ($country -eq "en-GB") {
            $country = "UK"
        }
        Write-Host "[✔ ] ~ Region set to UK" -ForegroundColor Green
        Start-Sleep -Seconds 2

    }
    "2" {
       # Set the desired values for the country/region settings
        $countryCode = "DE"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer
        $country = "Rome - Germany"
        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "3" {
        # Set the desired values for the country/region settings
        $countryCode = "KW"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer




        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "4" {
        # Set the desired values for the country/region settings
        $countryCode = "EG"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer
         $country = "Egypt"
        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "5" {
        # Set the desired values for the country/region settings
        $countryCode = "FR"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer
        $country = "Bourgogne-Franche"
        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2
    }
    "6" {
       
        # Set the desired values for the country/region settings
        $countryCode = "IT"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer
        $country = "Italy"
        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2


    }
    "7" {
        # Set the desired values for the country/region settings
        $countryCode = "AE"   # Country/Region code (e.g., KW for Kuwait)

        # Set the regional settings using RegionInfo class
        $region = New-Object -TypeName System.Globalization.RegionInfo -ArgumentList $countryCode
        Set-WinHomeLocation -GeoId $region.GeoId

        # Optional: Restart your computer for the changes to take effect
        # Restart-Computer
         $country = "Abu Dhabi"
        Write-Host "[✔] ~ Region set to $country" -ForegroundColor Green
        Start-Sleep -Seconds 2

    }

    Default {
        Write-Host "Invalid choice. Please enter a valid option (1, for UK )."
    }
}

#INSTALLING ONVIF------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$onvif = "C:\Program Files (x86)\Synesis\ONVIF Device Manager\odm.exe"

if (Test-Path $onvif) {
    Write-Host "[INFO] Onvif Device Manager is already installed in the system, no action taken" -ForegroundColor Yellow
    
} else {
    Write-Host "[...] Installing Onvif"

    $msiPath = Join-Path -Path $currentDirectory -ChildPath "Camera's Tool\Onvif Device Manager.msi"
    $arguments = "/qn"

    if (Test-Path -Path $msiPath) {
        # Check for administrative privileges
        $isElevated = ([System.Security.Principal.WindowsPrincipal] [System.Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)

        if ($isElevated) {
            Start-Process msiexec.exe -ArgumentList "/i `"$msiPath`" $arguments /l*v `"$currentDirectory\Logs\ONVIF_install.log`"" -Wait
            Write-Host "[✔ ] Onvif Installed" -ForegroundColor Green
        } else {
            Write-Host "[ERROR] Insufficient permissions. Run the script as an administrator." -ForegroundColor Red
            $result = "`n[X] Insufficient permissions. Run the script as an administrator."
        }
    } else {
        Write-Host "Installation file not found."
    }
}

#INSTALLING PRONTO------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$folderPath = Join-Path -Path $currentDirectory -ChildPath "Camera's Tool/PRONTO"

$prontoExePath = "C:\Program Files\PRONTO Device Manager\PRONTO Device Manager.exe"
$msiPath = Get-ChildItem -Path $folderPath -Filter '*.msi' | Select-Object -First 1 -ExpandProperty FullName



if (Test-Path -Path $prontoExePath) {
    Write-Host "[INFO] PRONTO Device Manager is already installed, no action taken" -ForegroundColor Yellow
} else {
    if (Test-Path -Path $msiPath) {
        Write-Host "[...] Installing PRONTO"
        
        $arguments = "/qn /l*v `"$currentDirectory\Logs\PRONTO_install.log`""
        Start-Process msiexec.exe -ArgumentList "/i `"$msiPath`" $arguments" -Wait
        
        if (Test-Path -Path $prontoExePath) {
            Write-Host "[✔ ] PRONTO Installed" -ForegroundColor Green
        } else {
            Write-Host "[❌ ] PRONTO installation failed" -ForegroundColor Red
        }
    } else {
        Write-Host "[❌ ] No PRONTO MSI installer found in the folder" -ForegroundColor Red
    }
}


#PRONTO PDF to Desktop------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$folderPath = Join-Path -Path $currentDirectory -ChildPath "Camera's Tool/PRONTO"

$matchingPdfFiles = Get-ChildItem -Path $folderPath -Filter "*Pronto*.pdf" -File

foreach ($pdfFile in $matchingPdfFiles) {
    try {
        $destinationPath = Join-Path -Path $env:USERPROFILE\Desktop -ChildPath $pdfFile.Name
        Copy-Item -Path $pdfFile.FullName -Destination $destinationPath -Force
        Write-Host "[✔ ] ~ $($pdfFile.Name) sent to Desktop" -ForegroundColor Green
    } catch {
        $errorMessage = $_.Exception.Message
        Write-Host "[❌ ] ~ An error occurred while copying $($pdfFile.Name): $errorMessage" -ForegroundColor Red
        $result += "`n[X] ~ An error occurred while copying $($pdfFile.Name): $errorMessage"
    }
}

#Valerus Documents to Desktop------------------------------------------------------------

switch ($choiceM) {
    "1" {
        $currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
        $folderPathDoc = Join-Path -Path $currentDirectory -ChildPath "Camera's Tool"
        $icon = Join-Path -Path $currentDirectory -ChildPath "Camera's Tool/ViconNet-Valerus Docs Icon.ico"

        # Check the current user's username
        $currentUserName = $env:USERNAME

        $DocPath = Join-Path -Path $folderPathDoc -ChildPath "Valerus Documents"

        $destinationPath = Join-Path -Path "$env:USERPROFILE\Documents" -ChildPath "Valerus Documents"

        try {
         if (Test-Path -Path $destinationPath) {
             Write-Host "[✔ ] ~ Valerus Documents folder already exists in the destination" -ForegroundColor Green
            } else {
                Copy-Item -Path $DocPath -Destination $destinationPath -Recurse
                Write-Host "[✔ ] ~ Valerus Documents sent to Documents folder" -ForegroundColor Green

                # Create a shortcut on the desktop
                $shortcutPath = Join-Path -Path "$env:USERPROFILE\Desktop" -ChildPath "Valerus Documents.lnk"
                $shell = New-Object -ComObject WScript.Shell
                $shortcut = $shell.CreateShortcut($shortcutPath)
                $shortcut.TargetPath = $destinationPath
                $shortcut.IconLocation = $icon
                $shortcut.Save()

                Write-Host "[✔ ] ~ Shortcut created on the desktop" -ForegroundColor Green
            }
        } catch {
            $errorMessage = $_.Exception.Message
            Write-Host "[❌ ] ~ An error occurred: $errorMessage" -ForegroundColor Red
        }
       
    }
    "2" {
        #------------------------------------Valerus Client PDF to Desktop------------------------------------------------------------
        
        $currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path 
        $pdfPath = Join-Path -Path $currentDirectory -ChildPath "Thick Client (OnBoard Graphics Only)"

        
        $matchingPdfFiles = Get-ChildItem -Path $folderPath -Filter "*.pdf" -File

        foreach ($pdfFile in $matchingPdfFiles) {
            try {
            
                $destinationPath = Join-Path -Path $env:USERPROFILE\Desktop -ChildPath $pdfFile.Name
                Copy-Item -Path $pdfFile.FullName -Destination $destinationPath -Force
                Write-Host "[✔ ] ~ $($pdfFile.Name) sent to Desktop" -ForegroundColor Green
            } catch {
                $errorMessage = $_.Exception.Message
                Write-Host "[❌] ~ An error occurred while copying $($pdfFile.Name): $errorMessage" -ForegroundColor Red
                $result += "`n[X] ~ An error occurred while copying $($pdfFile.Name): $errorMessage"
            }
        }
        
            }
    "3" {
        #------------------------------------Thick Client PDF to Desktop------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path 



$pdfPath2 = Join-Path -Path $currentDirectory -ChildPath "Thick Client (Graphics Card Only)\Desktop-Client_QuickGuide.pdf"

try
{
    Copy-Item  -Path $pdfPath2  -Destination "$env:USERPROFILE\Desktop"
    Write-Host "[✔ ] ~ Thick Client PDF sent to Desktop" -ForegroundColor Green
}
catch
{
    $errorMessage = $_.Exception.Message
    Write-Host "[❌] ~ An error occurred while copying the PDF file: $errorMessage" -ForegroundColor Red
    $result += "`n[X] ~ An error occurred while copying the PDF file: The username is not either Operator or VII"
}
        
    }
    Default {
        
    }
}

#INSTALLING VALERUS------------------------------------------------------------

switch ($choiceM) {
    "1" {
       # Get the current location of the script
$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$valerusLauncher = "C:\Program Files\Vicon\Launcher\Valerus VMS Launcher.exe"
$folderPath = Join-Path -Path $currentDirectory -ChildPath 'Valerus'

# Construct paths for .NET Framework and Valerus installation
$folderPath2 = Join-Path -Path $folderPath -ChildPath 'Net_Framework'
$exePath2 = Get-ChildItem -Path $folderPath2 -Filter '*.exe' | Select-Object -First 1 -ExpandProperty FullName
$exePath = Get-ChildItem -Path $folderPath -Filter '*.exe' | Select-Object -First 1 -ExpandProperty FullName

$exeName = Split-Path -Path $exePath -Leaf

$numbers = [regex]::Matches($exeName, '\d+').Value -join '.'


# Verify that the .NET Framework installation file exists
if (Test-Path -Path $exePath2) {
    # Run the .NET Framework installation file
    Write-Host "[...] ~ Installing Net Framework, this might take a few minutes"
    Start-Process -FilePath $exePath2 -ArgumentList "/q" -Verb "runas" -Wait
}
else {
    Write-Host "Installation file not found: $exePath2"
    exit 1
}

# Verify that the Valerus installation file exists
if (Test-Path -Path $exePath) {
    # Run the Valerus installation file
    Write-Host "[...] ~ Installing Valerus, this might take a few minutes"
    Start-Process -FilePath $exePath -ArgumentList "/q" -Verb "runas" -Wait
}
else {
    Write-Host "Installation file not found: $exePath"
    exit 1
}

# Check if the AppServer path exists
$maxAttempts = 3
$currentAttempt = 0
$installed = $false

do {
    $currentAttempt++
    
    # Check if the AppServer path exists
    if (Test-Path -Path "C:\Program Files\Vicon\AppServer") {
        Write-Host "Installation completed successfully."
        $installed = $true
    }
    else {
        Write-Host "AppServer path not found. Attempt $currentAttempt of $maxAttempts. Rerunning the installation."
    }
}
while (-not $installed -and $currentAttempt -lt $maxAttempts)

# If installation was not successful after max attempts, show an error message
if (-not $installed) {
    Write-Host "Installation failed after $maxAttempts attempts."
}


#Clear-Host
       
    }
    "2" {
        #------------------------------------INSTALLING VALERUS CLIENT------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$valerusLauncherClient = "C:\Program Files\Valerus Client\Valerus.Bootstrapper.exe"
$counterLimit = 2
$folderPath = Join-Path -Path $currentDirectory -ChildPath 'Thick Client (OnBoard Graphics Only)'

$exePath = Get-ChildItem -Path $folderPath -Filter '*.exe' | Select-Object -First 1 -ExpandProperty FullName
$exeName = Split-Path -Path $exePath -Leaf

$numbers = [regex]::Matches($exeName, '\d+').Value -join '.'


Write-Host "[...] ~ Installing Valerus, this might take a few minutes"


Start-Process -FilePath $exePath -ArgumentList "/q" -Verb "runas" -Wait
        
    }
    "3" {
       #------------------------------------INSTALLING VALERUS CLIENT------------------------------------------------------------

$currentDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$valerusLauncherClient = "C:\Program Files\Valerus Client\Valerus.Bootstrapper.exe"
$counterLimit = 2
$folderPath = Join-Path -Path $currentDirectory -ChildPath 'Thick Client (Graphics Card Only)/Resources'
$folderPathVal = Join-Path -Path $currentDirectory -ChildPath 'Thick Client (Graphics Card Only)'

# Find dotnet-runtime
$dotnetRuntimePath = Get-ChildItem -Path $folderPath -Filter 'dotnet-runtime-*-win-x64.exe' | Select-Object -First 1 -ExpandProperty FullName

# Find gstreamer-1.0-devel-msvc
$gstreamerDevelPath = Get-ChildItem -Path $folderPath -Filter 'gstreamer-1.0-devel-msvc-x86_64-*.msi' | Select-Object -First 1 -ExpandProperty FullName

# Find gstreamer-1.0-msvc
$gstreamerPath = Get-ChildItem -Path $folderPath -Filter 'gstreamer-1.0-msvc-x86_64-*.msi' | Select-Object -First 1 -ExpandProperty FullName

# Find VC_redist.x64
$vcRedistPath = Get-ChildItem -Path $folderPath -Filter 'VC_redist.x64.exe' | Select-Object -First 1 -ExpandProperty FullName

# Find windowsdesktop-runtime
$windowsRuntimePath = Get-ChildItem -Path $folderPath -Filter 'windowsdesktop-runtime-*-win-x64.exe' | Select-Object -First 1 -ExpandProperty FullName


$exePath = Get-ChildItem -Path $folderPath -Filter '*.exe' | Select-Object -First 1 -ExpandProperty FullName
$exePathVal = Get-ChildItem -Path $folderPathVal -Filter '*.exe' | Select-Object -First 1 -ExpandProperty FullName  
$exeName = Split-Path -Path $exePath -Leaf

$numbers = [regex]::Matches($exeName, '\d+').Value -join '.'

Write-Host "[...] ~ Installing Valerus, this might take a few minutes"
$arguments = "/S /norestart /SelectAll"

Start-Process -FilePath $exePathVal -ArgumentList $arguments -Verb "runas" -Wait



Start-Process -FilePath $exePath -ArgumentList $arguments -Verb "runas" -Wait


$dotnetRuntimeInstalled = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "dotnet-runtime-*" }

if ($dotnetRuntimeInstalled) {
    Write-Host "Uninstalling dotnet-runtime..."
    Start-Process -Wait -FilePath msiexec.exe -ArgumentList "/x $($dotnetRuntimeInstalled.IdentifyingNumber) /quiet"
}

$gstreamerDevelInstalled = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "gstreamer-1.0-devel-msvc-x86_64-*" }

if ($gstreamerDevelInstalled) {
    Write-Host "Uninstalling gstreamer-1.0-devel-msvc..."
    Start-Process -Wait -FilePath msiexec.exe -ArgumentList "/x $($gstreamerDevelInstalled.IdentifyingNumber) /quiet"
}

$gstreamerInstalled = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "gstreamer-1.0-msvc-x86_64-*" }

if ($gstreamerInstalled) {
    Write-Host "Uninstalling gstreamer-1.0-msvc..."
    Start-Process -Wait -FilePath msiexec.exe -ArgumentList "/x $($gstreamerInstalled.IdentifyingNumber) /quiet"
}

$vcRedistInstalled = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "VC_redist.x64" }

if ($vcRedistInstalled) {
    Write-Host "Uninstalling VC_redist.x64..."
    Start-Process -Wait -FilePath msiexec.exe -ArgumentList "/x $($vcRedistInstalled.IdentifyingNumber) /quiet"
}

$windowsRuntimeInstalled = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "windowsdesktop-runtime-*" }

if ($windowsRuntimeInstalled) {
    Write-Host "Uninstalling windowsdesktop-runtime..."
    Start-Process -Wait -FilePath msiexec.exe -ArgumentList "/x $($windowsRuntimeInstalled.IdentifyingNumber) /quiet"
}

Write-Host " "
Write-Host "[***] ~ Additional Resources"
Write-Host "________________________________"
Write-Host " "
Write-Host "[1/6] ~ Installing components..." #dotnet-runtime
Start-Process -Wait -FilePath $dotnetRuntimePath -ArgumentList "/quiet"

Write-Host "[2/6] ~ Installing components..."#gstreamer-1.0-devel-msvc
Start-Process -FilePath "msiexec.exe" -ArgumentList "/i", "`"$gstreamerDevelPath`"", "/quiet" -Wait

Write-Host "[3/6] ~ Installing components..."#gstreamer-1.0-msvc
Start-Process -FilePath "msiexec.exe" -ArgumentList "/i", "`"$gstreamerPath`"", "/quiet" -Wait

Write-Host "[4/6] ~ Installing components..."#VC_redist.x64
Start-Process -Wait -FilePath $vcRedistPath -ArgumentList "/quiet"

Write-Host "[5/6] ~ Installing components..."#windowsdesktop-runtime
Start-Process -Wait -FilePath $windowsRuntimePath -ArgumentList "/quiet"

# Add GStreamer environment variable
Write-Output "[6/6] ~ Adding GStreamer environment variable..."
[Environment]::SetEnvironmentVariable("GSTREAMER_1_0_ROOT_MSVC_X86_64", "C:\gstreamer\1.0\msvc_x86_64\", [EnvironmentVariableTarget]::Machine)

        
    }
    Default {
        
    }
}

#ADDITIONAL INFORMATION-------------------------------------

Write-Host " "
Write-Host " INSTALLATION COMPLETE " -ForegroundColor Green
Write-Host " "

#Green screen********************************
[console]::beep()
Add-Type -AssemblyName System.Windows.Forms

$folderPathImage = Join-Path -Path $currentDirectory -ChildPath 'Script_Resources'
$filePathImage = Join-Path -Path $folderPathImage -ChildPath "light-green-plain.jpg"

# Create a form
$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
$form.BackColor = [System.Drawing.Color]::Black
$form.TopMost = $true

# Create a PictureBox control and load the image
$pictureBox = New-Object System.Windows.Forms.PictureBox
$pictureBox.Dock = [System.Windows.Forms.DockStyle]::Fill
$pictureBox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$pictureBox.ImageLocation = $filePathImage

$form.Controls.Add($pictureBox)


# Event handler for key down
$KeyDownEventHandler = {
    # Close the form if any key is pressed
    $form.Close()
}

# Register the event handler for the KeyDown event of the form
$pictureBox.Add_KeyDown($KeyDownEventHandler)
$pictureBox.Add_Click($KeyDownEventHandler)



# Show the form and activate it to receive focus

$form.ShowDialog()
$form.Activate()


#*********************************************
$poNumber = Read-Host "[1/6] INSERT THE PO NUMBER"
while ([string]::IsNullOrWhiteSpace($poNumber)) {
    Write-Host " "
    Write-Host "Invalid input. The PO number cannot be empty. Please try again." -ForegroundColor Red
    Write-Host " "
    $poNumber = Read-Host "[1/5] INSERT THE PO NUMBER"
    Write-Host " "
}

$custNumber = Read-Host "[2/6] INSERT THE CUSTOMER NAME"
while ([string]::IsNullOrWhiteSpace($custNumber)) {
    Write-Host " "
    Write-Host "Invalid input. The customer name cannot be empty. Please try again." -ForegroundColor Red
    Write-Host " "
    $custNumber = Read-Host "[2/3] INSERT THE CUSTOMER NAME"
    Write-Host " "
}

$prodNumber = Read-Host "[3/6] INSERT THE PRODUCT CODE"
while ([string]::IsNullOrWhiteSpace($prodNumber)) {
Write-Host " "
    Write-Host "Invalid input. The product number cannot be empty. Please try again." -ForegroundColor Red
    Write-Host " "
    $prodNumber = Read-Host "[3/3] INSERT THE PRODUCT NUMBER"
    Write-Host " "
}

$modelNumber = Read-Host "[3/6] INSERT THE MODEL"
while ([string]::IsNullOrWhiteSpace($modelNumber)) {
Write-Host " "
    Write-Host "Invalid input. The model cannot be empty. Please try again." -ForegroundColor Red
    Write-Host " "
    $prodNumber = Read-Host "[3/6] INSERT THE MODEL"
    Write-Host " "
}

$unit = Read-Host "Is this a Novatech unit? (answer 'Y' or 'N')"

if ($unit -eq "y") {
    $build = Read-Host "Please provide the build of the Novatech unit "
    $serialNumber = Read-Host "Please provide the serial number of the Novatech unit "

    $nova = "NOVATECH UNIT"
    # Process the build and serial number as needed
    # ...
    Write-Host "Build: $build"
    Write-Host "Serial Number: $serialNumber"
}

elseif($unit -eq "n"){
    $nova = "VICON UNIT"
    $build = "N/A"
    $serialNumber = "N/A"
}


#Module Name

#ask if is a NOvatech unit
### build
### serial number


#HDD none raid info


$valVersion = $numbers
$computerInfo = Get-ComputerInfo | ConvertTo-Json -Depth 10
Write-Host " "


#Start-Process -FilePath "notepad.exe" -ArgumentList $filePath -Wait
Rename-Computer -NewName $newName -Force 

#NON HDD INFO---------------------------------------

$disks = Get-Disk | Format-Table -AutoSize | Out-String 

#RAID INFO---------------------------------------

# Check if MegaRAID Storage Manager installation folder exists

if (Test-Path "C:\Program Files (x86)\MegaRAID Storage Manager") {
   # Change directory to MegaRAID Storage Manager installation folder
cd "C:\Program Files (x86)\MegaRAID Storage Manager"

# Execute storcli64.exe command
$resultRAID = .\storcli64.exe /c0 /eall /sall show | Select-Object -Skip 3 | Where-Object { $_ -notmatch 'Slt-Slot|DG-DriveGroup|Spare|UGood-Unconfigured|Encryptive|Info|shielded|Shielded' } | ForEach-Object { ($_ -split '\s+')[2,4,5,6,10,11] -join "`t" }

.\storcli64.exe /c0 /eall /sall show | Select-Object -Skip 3 | Where-Object { $_ -notmatch 'Slt-Slot|DG-DriveGroup|Spare|UGood-Unconfigured|Encryptive|Info|shielded|Shielded' } | ForEach-Object { ($_ -split '\s+')[2,4,5,6,10,11] -join "`t" }


# Count the number of HDDs
$count = ($resultRAID | Select-String -Pattern "Onln" | Measure-Object).Count

#Write-Host $result

# Display the count
Write-Host "Number HDD online: "$count

# Initialize a counter variable
$count2 = 0

# Iterate through each line of the output and count HDD entries
foreach ($line in $resultRAID) {
    # Check if the line contains any size information
    if ($line -match "\d+(\.\d+)?\sTB") {
        $count2++
    }
}

    # Display the count
    Write-Host "Number HDD total: "$count2

 
    Write-Host " "
    #Write-Host "Press Enter to exit..."
    #$null = Read-Host

} else {
    # Display message if MegaRAID Storage Manager installation folder is not found
    Write-Host "[INFO] ~ MegaRAID Storage Manager is not installed on this system. No action taken" -ForegroundColor Yellow
    Write-Host " "
    $resultRAID = "No RAID detected"

}

#DEVICES INFO---------------------------------------

$diplay = Get-PnpDevice -Class "Display" | Out-String 

$ram = Get-WmiObject -Class Win32_PhysicalMemory | Select-Object Manufacturer, @{Name="CapacityGB"; Expression={$_.Capacity / 1GB}}, Speed, PartNumber | Out-String

$mother = Get-WmiObject -Class Win32_BaseBoard | Select-Object Manufacturer, Product, SerialNumber, Version | Out-String



#GAMMA SERVER-------------------------------------

# Create the network drive with the specified credentials
New-PSDrive -Name $driveLetter -PSProvider FileSystem -Root $networkPath -Credential (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $password) -Persist | Out-Null


#REPORT BACK-------------------------------------


# Create the content to be appended
$content = @"

VALERUS QC CHECKLIST
------------------------- 

                                         
 [X] PC Name: $newName 
 [X] Serial Number: $date 
 [X] Country: $country 
 [X] Date: $datePerformed 
 [X] PO#: $poNumber
 [X] Customer Name: $custNumber
 [X] Product Code: $prodNumber
 [X] Model: $modelNumber
 [X] Valerus Version: $valVersion

 $nova
 ___________________________________________________________________

 [X] Build: $build
 [X] Serial Number: $serialNumber


 NON-RAID HDD INFO
 ___________________________________________________________________

 $disks


 WARNINGS FOUND
 ___________________________________________________________________

 $result


 RAID INFORMATION
 ___________________________________________________________________

 $resultRAID


 DEVICE MANAGER INFO
___________________________________________________________________

$diplay  

$ram 

$mother


 PC INFORMATION
 ___________________________________________________________________

 $computerInfo



"@

# Set the custom title for the file
$fileTitle = "PO#$poNumber-$newName.txt"
$filePath = Join-Path -Path 'Z:\QC_INFO' -ChildPath $fileTitle


try {
    if (Test-Path "PO#$poNumber") {
        Write-Host " "
        Write-Host "[INFO] ~ The PO number already exists" -ForegroundColor Yellow
        Write-Host " "
        Write-Host "Choose an option:"
        Write-Host " "
        Write-Host "1. Change the PO number"
        Write-Host "2. Override the existing file"
        Write-Host " "
        $choice = Read-Host "Enter your choice (1 or 2)"
        
        if ($choice -eq "1") {

            $poNumber = Read-Host "INSERT THE PO NUMBER" 
        }
        elseif ($choice -eq "2") {
            # Override the existing file
            $filePath = Join-Path -Path 'Z:\QC_INFO' -ChildPath $fileTitle
            $content | Out-File -FilePath $filePath -Encoding ASCII -Force
            Write-Host "[INFO] ~ File overridden successfully" -ForegroundColor Green


        }
        else {
            Write-Host "[INFO] ~ Invalid choice. Exiting..." -ForegroundColor Yellow
        }
    }
    else {
        # Create or append to the file with the desired file title
        $filePath = Join-Path -Path 'Z:\QC_INFO' -ChildPath $fileTitle
        $content | Out-File -FilePath $filePath -Encoding ASCII -Append
    }
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Host "[❌] ~ An error occurred while copying the PDF file: $errorMessage" -ForegroundColor Red
    $result += "`n[X] ~ An error occurred while copying the PDF file: The username is not either Operator or VII"
}


# Create or append to the file with the desired file title
#$filePath = Join-Path -Path 'Z:\QC_INFO' -ChildPath $fileTitle
#$content | Out-File -FilePath $filePath -Encoding ASCII -Append

# Open Notepad with the created file





switch ($choiceM) {
    "1" {
       
       Start-Process -FilePath $valerusLauncher
       
    }
    "2" {
        
        Start-Process -FilePath $valerusLauncherClient
        
            }
    "3" {

   
    Start-Process -FilePath $valerusLauncherClient
        
    }
    Default {
        
    }
}



Start-Sleep -Seconds 2

powershell.exe -Command "Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Restricted"

# Remove the network drive when done (optional)
Remove-PSDrive -Name $driveLetter #-Restart


Start-Sleep -Seconds 2

#Restart-Computer

Exit